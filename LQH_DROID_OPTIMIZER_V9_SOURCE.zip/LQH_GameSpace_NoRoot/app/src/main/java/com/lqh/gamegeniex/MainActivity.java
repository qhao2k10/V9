package com.lqh.gamegeniex;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private static final String PREF = "lqh_v9_droid_optimizer_pref";
    private static final int BG = Color.rgb(4, 7, 18);
    private static final int CARD = Color.rgb(18, 25, 48);
    private static final int CARD_DARK = Color.rgb(9, 13, 28);
    private static final int PURPLE = Color.rgb(128, 89, 255);
    private static final int CYAN = Color.rgb(38, 222, 210);
    private static final int BLUE = Color.rgb(79, 124, 255);
    private static final int PINK = Color.rgb(255, 47, 91);
    private static final int YELLOW = Color.rgb(255, 196, 59);
    private static final int MUTED = Color.rgb(176, 187, 220);

    private final Handler handler = new Handler();
    private final Random random = new Random();
    private final ArrayList<AppItem> apps = new ArrayList<>();

    private SharedPreferences sp;
    private LinearLayout root;
    private LinearLayout content;
    private TextView homeNav;
    private TextView boostNav;
    private TextView selectedNameView;
    private TextView selectedPkgView;
    private TextView liveStats;
    private TextView miniStats;
    private TextView console;
    private LinearLayout appList;
    private String tab = "home";

    private final Runnable liveLoop = new Runnable() {
        @Override public void run() {
            updateLiveStats();
            handler.postDelayed(this, updateDelayMs());
        }
    };

    private static class AppItem {
        String label;
        String pkg;
        Drawable icon;
        boolean likelyGame;
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp = getSharedPreferences(PREF, MODE_PRIVATE);
        seedDefaults();
        loadLaunchableApps();
        buildShell();
        showHome();
        handler.post(liveLoop);
    }

    @Override protected void onResume() {
        super.onResume();
        applyRuntimeMode();
        updateLiveStats();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(liveLoop);
        super.onDestroy();
    }

    private void seedDefaults() {
        SharedPreferences.Editor e = sp.edit();
        if (!sp.contains("profile")) e.putString("profile", "PRO");
        if (!sp.contains("selectedName")) e.putString("selectedName", "Chưa chọn app");
        if (!sp.contains("selectedPkg")) e.putString("selectedPkg", "Vào tab Boost để chọn target");
        if (!sp.contains("performance")) e.putBoolean("performance", true);
        if (!sp.contains("touch")) e.putBoolean("touch", true);
        if (!sp.contains("ram")) e.putBoolean("ram", true);
        if (!sp.contains("cooler")) e.putBoolean("cooler", false);
        if (!sp.contains("charge")) e.putBoolean("charge", false);
        if (!sp.contains("network")) e.putBoolean("network", true);
        if (!sp.contains("awake")) e.putBoolean("awake", true);
        if (!sp.contains("refresh")) e.putBoolean("refresh", true);
        if (!sp.contains("fx")) e.putBoolean("fx", true);
        if (!sp.contains("autoGuard")) e.putBoolean("autoGuard", true);
        e.apply();
    }

    private void buildShell() {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 21) {
            w.setStatusBarColor(Color.rgb(2, 3, 10));
            w.setNavigationBarColor(Color.rgb(2, 3, 10));
        }
        applyRuntimeMode();

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(background());
        setContentView(root);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(18), dp(14), dp(10));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, lp(-1, 0, 0, 0, 0, 0, 1));

        LinearLayout nav = row();
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(12), dp(10), dp(12), dp(10));
        nav.setBackground(box(Color.rgb(15, 20, 42), Color.rgb(27, 34, 65), 28, 1));
        root.addView(nav, lp(-1, dp(78), dp(14), dp(0), dp(14), dp(12)));

        homeNav = navItem("◆ Home");
        boostNav = navItem("⚡ Boost");
        homeNav.setOnClickListener(v -> showHome());
        boostNav.setOnClickListener(v -> showBoost());
        nav.addView(homeNav, lp(0, -1, 0, 0, 6, 0, 1));
        nav.addView(boostNav, lp(0, -1, 6, 0, 0, 0, 1));
    }

    private void showHome() {
        tab = "home";
        resetDynamicRefs();
        content.removeAllViews();
        styleNavs();

        addHeader("LQH Droid Optimizer", "Tối ưu chơi game, nghe nhạc, tải MP3 direct link", "Bản quyền LQH • No root • No ADB • No Shizuku");
        addSelectedTargetCard();
        addQuickProfiles();
        addOptimizerCards();
        addLiveDashboard();
        addSystemShortcutPanel();
        addConsole("READY: V9 Droid Optimizer loaded. Safe no-root tuning only.");
        updateLiveStats();
    }

    private void showBoost() {
        tab = "boost";
        resetDynamicRefs();
        content.removeAllViews();
        styleNavs();

        addHeader("Game Booster", "Speed up và fix lag theo kiểu an toàn, không cần root", "Bản quyền LQH • No root • No ADB • No Shizuku");
        addSearchAndAppList();
        addBoostActionPanel();
        addConsole("BOOST: Chọn app/game, rồi Apply Boost. Không sửa file game, không bypass hệ thống.");
        updateLiveStats();
    }

    private void resetDynamicRefs() {
        selectedNameView = null;
        selectedPkgView = null;
        liveStats = null;
        miniStats = null;
        console = null;
        appList = null;
    }

    private void addHeader(String title, String sub, String badge) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(dp(2), dp(8), dp(2), dp(14));

        TextView t = text(title, 28, PURPLE, true);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setShadowLayer(sp.getBoolean("fx", true) ? 24 : 0, 0, 0, Color.argb(220, 112, 86, 255));
        header.addView(t, lp(-1, -2, 0, 0, 0, 6));

        TextView s = text(sub, 14, Color.rgb(181, 190, 222), false);
        s.setGravity(Gravity.CENTER);
        header.addView(s, lp(-1, -2, 0, 0, 0, 8));

        TextView b = text(badge, 13, CYAN, true);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(b, lp(-1, -2, 0, 0, 0, 0));
        content.addView(header, lp(-1, -2, 0, 0, 0, 8));
    }

    private void addSelectedTargetCard() {
        LinearLayout card = panel(Color.rgb(42, 52, 92));
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(14), dp(18), dp(18));

        TextView label = text("Game đã chọn", 16, Color.rgb(175, 186, 218), true);
        card.addView(label, lp(-1, -2, 0, 0, 0, 2));

        selectedNameView = text(sp.getString("selectedName", "Chưa chọn app"), 26, Color.WHITE, true);
        selectedNameView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(selectedNameView, lp(-1, -2, 0, 0, 0, 2));

        selectedPkgView = text(sp.getString("selectedPkg", "Vào tab Boost để chọn target"), 12, MUTED, true);
        selectedPkgView.setSingleLine(false);
        card.addView(selectedPkgView, lp(-1, -2, 0, 0, 0, 14));

        LinearLayout actions = row();
        Button open = pillButton("Mở app", PURPLE, BLUE);
        Button boost = pillButton("Boost VIP", PURPLE, PINK);
        Button choose = pillButton("Chọn game", PURPLE, BLUE);
        open.setOnClickListener(v -> openSelectedApp());
        boost.setOnClickListener(v -> runOptimizer());
        choose.setOnClickListener(v -> showBoost());
        actions.addView(open, lp(0, dp(56), 0, 0, 6, 0, 1));
        actions.addView(boost, lp(0, dp(56), 6, 0, 6, 0, 1));
        actions.addView(choose, lp(0, dp(56), 6, 0, 0, 0, 1));
        card.addView(actions, lp(-1, -2, 0, 0, 0, 0));
        content.addView(card, lp(-1, -2, 0, 0, 0, 14));
    }

    private void addQuickProfiles() {
        LinearLayout wrap = panel(CYAN);
        wrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = sectionTitle("Gaming profile");
        wrap.addView(title, lp(-1, -2, 0, 0, 0, 10));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = row();
        hsv.addView(chips);
        addProfileChip(chips, "ECO", Color.rgb(32, 214, 126));
        addProfileChip(chips, "BAL", CYAN);
        addProfileChip(chips, "PRO", PURPLE);
        addProfileChip(chips, "MAX", PINK);
        addProfileChip(chips, "VIP", YELLOW);
        wrap.addView(hsv, lp(-1, -2, 0, 0, 0, 0));
        content.addView(wrap, lp(-1, -2, 0, 0, 0, 14));
    }

    private void addOptimizerCards() {
        content.addView(toggleCard("⚡", "Performance mode", "Giữ màn hình sáng, ưu tiên refresh trong app, profile gaming nhanh.", "performance", PURPLE), lp(-1, -2, 0, 0, 0, 10));
        content.addView(toggleCard("◎", "Max sensitivity", "Giảm cảm giác trễ trong app, haptic nhanh, thao tác phản hồi gọn.", "touch", CYAN), lp(-1, -2, 0, 0, 0, 10));
        content.addView(toggleCard("■", "RAM boost & cleanup", "Dọn cache của app, gọi GC, cập nhật trạng thái RAM tức thì.", "ram", Color.rgb(34, 216, 204)), lp(-1, -2, 0, 0, 0, 10));
        content.addView(toggleCard("▣", "Battery saver & cooler", "Tự giảm nhịp hiệu ứng khi máy nóng/pin thấp để app nhẹ hơn.", "cooler", Color.rgb(115, 214, 200)), lp(-1, -2, 0, 0, 0, 10));
        content.addView(toggleCard("◈", "Fast charging monitor", "Theo dõi trạng thái sạc, gợi ý giảm tải khi vừa sạc vừa chơi.", "charge", YELLOW), lp(-1, -2, 0, 0, 0, 10));
        content.addView(toggleCard("⊕", "Optimize Internet", "Theo dõi Wi‑Fi/mobile, kiểm tra trạng thái mạng và mở nhanh cài đặt mạng.", "network", Color.rgb(0, 173, 255)), lp(-1, -2, 0, 0, 0, 10));
        content.addView(toggleCard("Hz", "High refresh UI", "Yêu cầu tần số quét cao nhất cho cửa sổ app nếu thiết bị hỗ trợ.", "refresh", PINK), lp(-1, -2, 0, 0, 0, 10));
        content.addView(toggleCard("FX", "Neon visual FX", "Giữ hiệu ứng glow gaming; tắt để giao diện nhẹ hơn.", "fx", PURPLE), lp(-1, -2, 0, 0, 0, 10));
        content.addView(toggleCard("AI", "Auto Guard", "Tự cảnh báo khi nhiệt/pin không ổn và chuyển nhịp cập nhật an toàn.", "autoGuard", Color.rgb(32, 214, 126)), lp(-1, -2, 0, 0, 0, 14));
    }

    private void addLiveDashboard() {
        LinearLayout card = panel(PURPLE);
        card.setOrientation(LinearLayout.VERTICAL);
        card.addView(sectionTitle("Live dashboard"), lp(-1, -2, 0, 0, 0, 10));
        liveStats = text("", 14, Color.WHITE, true);
        liveStats.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        liveStats.setPadding(dp(14), dp(12), dp(14), dp(12));
        liveStats.setBackground(box(Color.rgb(7, 10, 24), CYAN, 18, 1));
        card.addView(liveStats, lp(-1, -2, 0, 0, 0, 0));
        content.addView(card, lp(-1, -2, 0, 0, 0, 14));
    }

    private void addSystemShortcutPanel() {
        LinearLayout card = panel(YELLOW);
        card.setOrientation(LinearLayout.VERTICAL);
        card.addView(sectionTitle("Safe tools"), lp(-1, -2, 0, 0, 0, 10));
        LinearLayout row1 = row();
        Button clean = darkButton("Clean cache", Color.rgb(34, 216, 204));
        Button network = darkButton("Network", Color.rgb(0, 173, 255));
        clean.setOnClickListener(v -> {
            long bytes = clearOwnCache();
            System.gc();
            toast("Đã dọn cache app: " + formatBytes(bytes));
            log("CLEAN: app cache removed " + formatBytes(bytes));
            updateLiveStats();
        });
        network.setOnClickListener(v -> openSettings(Settings.ACTION_WIFI_SETTINGS));
        row1.addView(clean, lp(0, dp(52), 0, 0, 6, 8, 1));
        row1.addView(network, lp(0, dp(52), 6, 0, 0, 8, 1));
        card.addView(row1, lp(-1, -2, 0, 0, 0, 0));

        LinearLayout row2 = row();
        Button display = darkButton("Display", PURPLE);
        Button appSettings = darkButton("App settings", PINK);
        display.setOnClickListener(v -> openSettings(Settings.ACTION_DISPLAY_SETTINGS));
        appSettings.setOnClickListener(v -> openSelectedAppSettings());
        row2.addView(display, lp(0, dp(52), 0, 0, 6, 0, 1));
        row2.addView(appSettings, lp(0, dp(52), 6, 0, 0, 0, 1));
        card.addView(row2, lp(-1, -2, 0, 0, 0, 0));
        content.addView(card, lp(-1, -2, 0, 0, 0, 14));
    }

    private void addSearchAndAppList() {
        EditText search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search all apps & games...");
        search.setTextColor(Color.WHITE);
        search.setHintTextColor(Color.rgb(132, 143, 178));
        search.setTextSize(15);
        search.setPadding(dp(18), dp(6), dp(18), dp(6));
        search.setBackground(box(Color.rgb(15, 21, 43), Color.rgb(43, 55, 96), 18, 1));
        content.addView(search, lp(-1, dp(58), 0, 0, 0, 14));

        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        content.addView(appList, lp(-1, -2, 0, 0, 0, 14));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderAppList(s.toString()); }
            @Override public void afterTextChanged(Editable s) { }
        });
        renderAppList("");
    }

    private void renderAppList(String query) {
        if (appList == null) return;
        appList.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        int count = 0;
        for (AppItem item : apps) {
            if (q.length() > 0 && !item.label.toLowerCase(Locale.ROOT).contains(q) && !item.pkg.toLowerCase(Locale.ROOT).contains(q)) continue;
            appList.addView(appCard(item), lp(-1, -2, 0, 0, 0, 10));
            count++;
            if (count >= 40) break;
        }
        if (count == 0) {
            TextView empty = text("Không tìm thấy app phù hợp", 14, MUTED, true);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(18), dp(18), dp(18));
            empty.setBackground(box(Color.rgb(15, 21, 43), Color.rgb(43, 55, 96), 18, 1));
            appList.addView(empty, lp(-1, -2, 0, 0, 0, 10));
        }
    }

    private LinearLayout appCard(AppItem item) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(box(CARD, Color.rgb(43, 55, 96), 22, 1));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(4));

        ImageView icon = new ImageView(this);
        if (item.icon != null) icon.setImageDrawable(item.icon);
        icon.setBackground(box(Color.rgb(27, 34, 65), Color.TRANSPARENT, 14, 0));
        icon.setPadding(dp(2), dp(2), dp(2), dp(2));
        card.addView(icon, lp(dp(54), dp(54), 0, 0, 12, 0));

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        TextView title = text(item.label, 18, Color.WHITE, true);
        TextView pkg = text(item.pkg, 12, MUTED, true);
        names.addView(title, lp(-1, -2, 0, 0, 0, 3));
        names.addView(pkg, lp(-1, -2, 0, 0, 0, 0));
        card.addView(names, lp(0, -2, 0, 0, 10, 0, 1));

        boolean selected = item.pkg.equals(sp.getString("selectedPkg", ""));
        Button pick = selected ? pillSmall("Đã chọn", PURPLE) : pillSmall(item.likelyGame ? "GAME" : "APP", PURPLE);
        pick.setOnClickListener(v -> selectApp(item));
        card.setOnClickListener(v -> selectApp(item));
        card.addView(pick, lp(dp(112), dp(50), 0, 0, 0, 0));
        return card;
    }

    private void addBoostActionPanel() {
        LinearLayout card = panel(PINK);
        card.setOrientation(LinearLayout.VERTICAL);
        card.addView(sectionTitle("Boost center"), lp(-1, -2, 0, 0, 0, 10));
        miniStats = text("", 13, Color.WHITE, true);
        miniStats.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        miniStats.setPadding(dp(14), dp(12), dp(14), dp(12));
        miniStats.setBackground(box(Color.rgb(7, 10, 24), CYAN, 16, 1));
        card.addView(miniStats, lp(-1, -2, 0, 0, 0, 12));

        LinearLayout actions = row();
        Button apply = pillButton("Apply Boost", PURPLE, PINK);
        Button open = pillButton("Open", PURPLE, BLUE);
        Button settings = pillButton("Settings", PURPLE, CYAN);
        apply.setOnClickListener(v -> runOptimizer());
        open.setOnClickListener(v -> openSelectedApp());
        settings.setOnClickListener(v -> openSelectedAppSettings());
        actions.addView(apply, lp(0, dp(54), 0, 0, 6, 0, 1));
        actions.addView(open, lp(0, dp(54), 6, 0, 6, 0, 1));
        actions.addView(settings, lp(0, dp(54), 6, 0, 0, 0, 1));
        card.addView(actions, lp(-1, -2, 0, 0, 0, 0));
        content.addView(card, lp(-1, -2, 0, 0, 0, 14));
    }

    private LinearLayout toggleCard(String iconText, String title, String desc, String key, int accent) {
        LinearLayout card = row();
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18), dp(18), dp(14), dp(18));
        card.setBackground(box(CARD, Color.rgb(43, 55, 96), 24, 1));
        if (Build.VERSION.SDK_INT >= 21) card.setElevation(dp(5));

        TextView icon = text(iconText, iconText.length() > 1 ? 14 : 26, accent, true);
        icon.setGravity(Gravity.CENTER);
        icon.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        icon.setShadowLayer(sp.getBoolean("fx", true) ? 16 : 0, 0, 0, accent);
        card.addView(icon, lp(dp(52), dp(52), 0, 0, 14, 0));

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        TextView tt = text(title, 20, Color.WHITE, true);
        TextView dd = text(desc, 13, MUTED, true);
        dd.setSingleLine(false);
        copy.addView(tt, lp(-1, -2, 0, 0, 0, 3));
        copy.addView(dd, lp(-1, -2, 0, 0, 0, 0));
        card.addView(copy, lp(0, -2, 0, 0, 12, 0, 1));

        Switch sw = new Switch(this);
        sw.setChecked(sp.getBoolean(key, false));
        sw.setOnCheckedChangeListener((buttonView, checked) -> {
            sp.edit().putBoolean(key, checked).apply();
            if ("fx".equals(key)) showHome();
            applyRuntimeMode();
            haptic(card);
            toast(title + ": " + (checked ? "ON" : "OFF"));
            log("TOGGLE: " + title + " = " + (checked ? "ON" : "OFF"));
        });
        card.addView(sw, lp(-2, -2, 0, 0, 0, 0));
        card.setOnClickListener(v -> sw.setChecked(!sw.isChecked()));
        return card;
    }

    private void addProfileChip(LinearLayout parent, String label, int accent) {
        TextView chip = text(label, 15, Color.WHITE, true);
        chip.setGravity(Gravity.CENTER);
        chip.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        chip.setPadding(dp(20), dp(11), dp(20), dp(11));
        boolean active = label.equals(sp.getString("profile", "PRO"));
        chip.setBackground(box(active ? accent : CARD_DARK, accent, 18, 1));
        chip.setShadowLayer(active && sp.getBoolean("fx", true) ? 14 : 0, 0, 0, accent);
        chip.setOnClickListener(v -> {
            applyProfile(label);
            showHome();
        });
        parent.addView(chip, lp(-2, dp(48), 0, 0, 10, 0));
    }

    private void applyProfile(String profile) {
        SharedPreferences.Editor e = sp.edit().putString("profile", profile);
        if ("ECO".equals(profile)) {
            e.putBoolean("performance", false).putBoolean("refresh", false).putBoolean("fx", false).putBoolean("cooler", true).putBoolean("awake", false);
        } else if ("BAL".equals(profile)) {
            e.putBoolean("performance", true).putBoolean("refresh", false).putBoolean("fx", true).putBoolean("cooler", false).putBoolean("awake", true);
        } else if ("PRO".equals(profile)) {
            e.putBoolean("performance", true).putBoolean("refresh", true).putBoolean("fx", true).putBoolean("cooler", false).putBoolean("awake", true);
        } else if ("MAX".equals(profile) || "VIP".equals(profile)) {
            e.putBoolean("performance", true).putBoolean("refresh", true).putBoolean("fx", true).putBoolean("touch", true).putBoolean("network", true).putBoolean("awake", true);
        }
        e.apply();
        applyRuntimeMode();
        toast("Profile: " + profile);
    }

    private void selectApp(AppItem item) {
        sp.edit().putString("selectedName", item.label).putString("selectedPkg", item.pkg).apply();
        haptic(root);
        toast("Đã chọn: " + item.label);
        if (selectedNameView != null) selectedNameView.setText(item.label);
        if (selectedPkgView != null) selectedPkgView.setText(item.pkg);
        renderAppList("");
        updateLiveStats();
    }

    private void runOptimizer() {
        long cleaned = 0;
        if (sp.getBoolean("ram", true)) {
            cleaned = clearOwnCache();
            System.gc();
        }
        applyRuntimeMode();
        haptic(root);
        String target = sp.getString("selectedName", "Chưa chọn app");
        String msg = "BOOST OK: " + target
                + " • profile " + sp.getString("profile", "PRO")
                + " • cache " + formatBytes(cleaned)
                + " • " + networkLabel()
                + " • " + batteryText();
        toast("Boost đã áp dụng");
        log(msg);
        updateLiveStats();
    }

    private void openSelectedApp() {
        String pkg = sp.getString("selectedPkg", "");
        if (pkg == null || pkg.length() == 0 || pkg.contains("Vào tab")) {
            toast("Chưa chọn app");
            showBoost();
            return;
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            toast("Không mở được app này");
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void openSelectedAppSettings() {
        String pkg = sp.getString("selectedPkg", getPackageName());
        if (pkg == null || pkg.length() == 0 || pkg.contains("Vào tab")) pkg = getPackageName();
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            startActivity(i);
        } catch (Exception e) {
            toast("Không mở được App settings");
        }
    }

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            toast("Không mở được cài đặt này");
        }
    }

    private void loadLaunchableApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(intent, 0);
        for (ResolveInfo ri : list) {
            if (ri.activityInfo == null || ri.activityInfo.packageName == null) continue;
            AppItem item = new AppItem();
            item.label = safeString(ri.loadLabel(pm));
            item.pkg = ri.activityInfo.packageName;
            item.icon = ri.loadIcon(pm);
            item.likelyGame = isLikelyGame(item, ri);
            apps.add(item);
        }
        Collections.sort(apps, new Comparator<AppItem>() {
            @Override public int compare(AppItem a, AppItem b) {
                if (a.likelyGame != b.likelyGame) return a.likelyGame ? -1 : 1;
                return a.label.compareToIgnoreCase(b.label);
            }
        });
    }

    private boolean isLikelyGame(AppItem item, ResolveInfo ri) {
        String x = (item.label + " " + item.pkg).toLowerCase(Locale.ROOT);
        if (x.contains("game") || x.contains("freefire") || x.contains("garena") || x.contains("pubg") || x.contains("mobile") || x.contains("lien") || x.contains("liên")) return true;
        if (Build.VERSION.SDK_INT >= 26 && ri.activityInfo != null && ri.activityInfo.applicationInfo != null) {
            return ri.activityInfo.applicationInfo.category == android.content.pm.ApplicationInfo.CATEGORY_GAME;
        }
        return false;
    }

    private void applyRuntimeMode() {
        Window w = getWindow();
        if (sp != null && (sp.getBoolean("awake", true) || sp.getBoolean("performance", true))) {
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        applyRefreshPreference();
    }

    private void applyRefreshPreference() {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            WindowManager.LayoutParams attrs = getWindow().getAttributes();
            attrs.preferredDisplayModeId = 0;
            if (sp != null && sp.getBoolean("refresh", true) && !sp.getBoolean("cooler", false)) {
                android.view.Display.Mode[] modes = getWindowManager().getDefaultDisplay().getSupportedModes();
                float best = 0f;
                int bestId = 0;
                for (android.view.Display.Mode mode : modes) {
                    if (mode.getRefreshRate() > best) {
                        best = mode.getRefreshRate();
                        bestId = mode.getModeId();
                    }
                }
                attrs.preferredDisplayModeId = bestId;
            }
            getWindow().setAttributes(attrs);
        } catch (Exception ignored) { }
    }

    private void updateLiveStats() {
        String target = sp.getString("selectedName", "Chưa chọn app");
        String profile = sp.getString("profile", "PRO");
        String lines = "TARGET  " + target
                + "\nPROFILE " + profile + " • " + modeText()
                + "\nBATTERY " + batteryText() + " • THERMAL " + thermalText()
                + "\nRAM     " + ramText()
                + "\nSTORAGE " + storageText()
                + "\nNETWORK " + networkLabel() + " • LAT " + latencyText()
                + "\nFPS SIM " + fpsText(profile) + " • SAFE NO-ROOT";
        if (liveStats != null) liveStats.setText(lines);
        if (miniStats != null) miniStats.setText(lines);
        if (selectedNameView != null) selectedNameView.setText(target);
        if (selectedPkgView != null) selectedPkgView.setText(sp.getString("selectedPkg", "Vào tab Boost để chọn target"));
        if (sp.getBoolean("autoGuard", true)) autoGuard();
    }

    private void autoGuard() {
        int pct = batteryPercent();
        float temp = batteryTempC();
        if (sp.getBoolean("cooler", false)) return;
        if ((temp >= 41.0f || (pct > 0 && pct <= 15)) && sp.getBoolean("performance", true)) {
            sp.edit().putBoolean("cooler", true).putBoolean("refresh", false).apply();
            applyRuntimeMode();
            log("AUTO GUARD: nhiệt/pin cao, đã chuyển sang Cooler Guard.");
        }
    }

    private long updateDelayMs() {
        if (sp == null) return 1200;
        if (sp.getBoolean("cooler", false)) return 2200;
        return sp.getBoolean("performance", true) ? 850 : 1500;
    }

    private String modeText() {
        if (sp.getBoolean("cooler", false)) return "COOLER";
        if (sp.getBoolean("performance", true)) return "GAMING";
        return "NORMAL";
    }

    private String fpsText(String profile) {
        int base;
        if ("VIP".equals(profile)) base = 144;
        else if ("MAX".equals(profile)) base = 120;
        else if ("PRO".equals(profile)) base = 90;
        else if ("BAL".equals(profile)) base = 60;
        else base = 45;
        if (sp.getBoolean("cooler", false)) base = Math.max(45, base - 20);
        return String.valueOf(Math.max(30, base - random.nextInt(5)));
    }

    private String latencyText() {
        if (!sp.getBoolean("network", true)) return "OFF";
        if ("OFFLINE".equals(networkLabel())) return "--";
        return (16 + random.nextInt(22)) + "ms";
    }

    private String batteryText() {
        int pct = batteryPercent();
        if (pct < 0) return "--%";
        boolean plugged = isPlugged();
        return pct + "%" + (plugged ? " CHG" : "");
    }

    private int batteryPercent() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return -1;
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        if (level < 0 || scale <= 0) return -1;
        return Math.round(level * 100f / scale);
    }

    private boolean isPlugged() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        return i != null && i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
    }

    private String thermalText() {
        float t = batteryTempC();
        if (t <= 0) return "--°C";
        return String.format(Locale.US, "%.1f°C", t);
    }

    private float batteryTempC() {
        Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return -1f;
        int temp = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        if (temp <= 0) return -1f;
        return temp / 10f;
    }

    private String ramText() {
        ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (am == null) return "--";
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long avail = mi.availMem / (1024L * 1024L);
        long total = Build.VERSION.SDK_INT >= 16 ? mi.totalMem / (1024L * 1024L) : 0;
        if (total > 0) {
            int pct = Math.round(avail * 100f / total);
            return avail + "MB free • " + pct + "%";
        }
        return avail + "MB free";
    }

    private String storageText() {
        try {
            StatFs stat = new StatFs(Environment.getDataDirectory().getPath());
            long free = stat.getAvailableBytes() / (1024L * 1024L * 1024L);
            long total = stat.getTotalBytes() / (1024L * 1024L * 1024L);
            int pct = total > 0 ? Math.round(free * 100f / total) : 0;
            return free + "GB free • " + pct + "%";
        } catch (Exception e) {
            return "--";
        }
    }

    private String networkLabel() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm == null) return "OFFLINE";
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni == null || !ni.isConnected()) return "OFFLINE";
            if (ni.getType() == ConnectivityManager.TYPE_WIFI) return "WIFI ONLINE";
            if (ni.getType() == ConnectivityManager.TYPE_MOBILE) return "MOBILE ONLINE";
            return "ONLINE";
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }

    private long clearOwnCache() {
        long bytes = 0;
        bytes += deleteContents(getCacheDir());
        if (Build.VERSION.SDK_INT >= 21) bytes += deleteContents(getCodeCacheDir());
        File ext = getExternalCacheDir();
        if (ext != null) bytes += deleteContents(ext);
        return bytes;
    }

    private long deleteContents(File file) {
        if (file == null || !file.exists()) return 0;
        long total = 0;
        File[] children = file.listFiles();
        if (children == null) return 0;
        for (File child : children) {
            if (child.isDirectory()) total += deleteContents(child);
            total += child.length();
            try { child.delete(); } catch (Exception ignored) { }
        }
        return total;
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1024L * 1024L) return (bytes / 1024L) + "KB";
        return (bytes / (1024L * 1024L)) + "MB";
    }

    private void log(String message) {
        if (console != null) console.setText(message);
    }

    private void haptic(View v) {
        if (v != null && sp.getBoolean("touch", true)) {
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
        }
    }

    private TextView sectionTitle(String value) {
        TextView t = text(value, 16, Color.WHITE, true);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void addConsole(String initial) {
        LinearLayout card = panel(CYAN);
        card.setOrientation(LinearLayout.VERTICAL);
        card.addView(sectionTitle("Command log"), lp(-1, -2, 0, 0, 0, 8));
        console = text(initial, 12, Color.rgb(178, 230, 255), false);
        console.setTypeface(Typeface.MONOSPACE);
        console.setPadding(dp(14), dp(10), dp(14), dp(10));
        console.setBackground(box(Color.rgb(7, 10, 24), Color.rgb(49, 64, 112), 16, 1));
        card.addView(console, lp(-1, -2, 0, 0, 0, 0));
        content.addView(card, lp(-1, -2, 0, 0, 0, 14));
    }

    private void styleNavs() {
        styleNav(homeNav, "home".equals(tab));
        styleNav(boostNav, "boost".equals(tab));
    }

    private void styleNav(TextView v, boolean active) {
        if (v == null) return;
        v.setTextColor(active ? PURPLE : MUTED);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setBackground(box(active ? Color.rgb(25, 31, 58) : Color.TRANSPARENT, active ? PURPLE : Color.TRANSPARENT, 22, active ? 1 : 0));
        v.setShadowLayer(active && sp.getBoolean("fx", true) ? 15 : 0, 0, 0, PURPLE);
    }

    private TextView navItem(String label) {
        TextView t = text(label, 17, MUTED, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(8), dp(8), dp(8));
        return t;
    }

    private LinearLayout panel(int stroke) {
        LinearLayout l = new LinearLayout(this);
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        l.setBackground(box(CARD, stroke, 24, 1));
        if (Build.VERSION.SDK_INT >= 21) l.setElevation(dp(5));
        return l;
    }

    private Button pillButton(String label, int start, int end) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), Color.rgb(152, 135, 255));
        b.setBackground(bg);
        return b;
    }

    private Button pillSmall(String label, int accent) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(box(accent, Color.rgb(152, 135, 255), 20, 1));
        return b;
    }

    private Button darkButton(String label, int accent) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setBackground(box(CARD_DARK, accent, 18, 1));
        return b;
    }

    private TextView text(String value, int spSize, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(spSize);
        t.setTextColor(color);
        t.setIncludeFontPadding(true);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private GradientDrawable background() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{
                Color.rgb(5, 7, 20), Color.rgb(6, 10, 25), Color.rgb(2, 4, 12)
        });
        return g;
    }

    private GradientDrawable box(int fill, int stroke, int radius, int strokeWidth) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        if (strokeWidth > 0) g.setStroke(dp(strokeWidth), stroke);
        return g;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, b);
        return p;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b, float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(l, t, r, b);
        return p;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private String safeString(CharSequence s) {
        if (s == null) return "Unknown";
        return s.toString();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
