# LQH Droid Optimizer V9

Safe no-root Android gaming-style optimizer UI.

## V9 changes
- Rebuilt in-app UI closer to the Game Booster / Droid Optimizer reference.
- Two-tab layout: Home and Boost.
- Searchable app/game selector with real launcher icons.
- Selected target card with Boost VIP, Open app, Choose game.
- Neon gaming cards and rounded bottom navigation.
- Safe no-root optimizer functions:
  - Keep screen awake while using the app.
  - High refresh-rate preference for the app window when supported.
  - Own-app cache cleanup.
  - Runtime RAM refresh using GC.
  - Battery and thermal monitor.
  - Auto Guard to reduce refresh/FX when hot or low battery.
  - Network status monitor and quick Wi-Fi settings shortcut.
  - App settings shortcut for the selected target.
  - Display settings shortcut.

The app does not use root, ADB, Shizuku, overlay HUD, game-file modification, bypass, or protected/private game APIs.
